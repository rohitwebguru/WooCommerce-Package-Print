<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div style="background:#fcf8e3; padding:10px; border:solid 1px #faebcc; color:#a66d3c; margin:50px 0px;">
	<b><?php _e('Oops !!!'); ?></b>	 <?php _e('No Cloud printing enabled documents found.', 'wf-woocommerce-packing-list'); ?>
</div>