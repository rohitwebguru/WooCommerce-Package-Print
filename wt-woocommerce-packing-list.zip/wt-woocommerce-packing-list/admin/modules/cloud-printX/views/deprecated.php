<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div style="background:#fcf8e3; padding:10px; border:solid 1px #faebcc; color:#a66d3c; margin:50px 0px;">
	<b><?php _e('Oops !!!'); ?></b>	 <?php echo sprintf(__('Cloud printing service has been deprecated by Google. We have launched an alternative service in tie up with PrintNode, try out the product %s here %s.', 'wf-woocommerce-packing-list'), '<a href="https://www.webtoffee.com/product/remote-print-woocommerce-pdf-invoice-printnode/" target="_blank">', '</a>'); ?>
</div>