<?php
$arr=array(
	'connection_status'=>sprintf(__('%sOnline%s: The online status indicates that the printer configured with your account is available for print. %s %sOffline%s: The offline status indicates that the printer configured with your account is not available for print e.g, switched off etc.','wf-woocommerce-packing-list'), '<b>', '</b>', '<br />', '<b>', '</b>'),
	'actions'=>sprintf(__('%sTest Printer%s: Click to test if the printer works properly. %s %sSet as default%s: Set a printer as default to have the prints redirected to it automatically.','wf-woocommerce-packing-list'), '<b>', '</b>', '<br />', '<b>', '</b>'),
);