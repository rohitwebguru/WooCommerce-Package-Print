<?php
$arr=array(
	'create_new_template'=>__('Click to view predefined templates.','wf-woocommerce-packing-list'),
	'dropdown_menu'=>__('Create a new template or edit an existing template.','wf-woocommerce-packing-list'),
	'help_icon'=>__('Lists general guidelines and the plugin placeholders that can help you while modifying the template via code editor, custom code.','wf-woocommerce-packing-list'),
	'code_view'=>__('Use CSS to make additional modifications to the layout other than the one listed in the visual editor.','wf-woocommerce-packing-list'),
	'design_view'=>__('Displays the currently chosen document template with provisions to modify.','wf-woocommerce-packing-list'),
	'preview_option'=>__('Shows a preview of the template on an actual order. Key in an order number to view the same.','wf-woocommerce-packing-list'),
);