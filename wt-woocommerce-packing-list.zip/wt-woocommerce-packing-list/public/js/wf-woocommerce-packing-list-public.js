(function( $ ) {
	'use strict';


})( jQuery );
