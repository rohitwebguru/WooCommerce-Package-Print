<?php
$arr=array(
	'wf_woocommerce_product_category_wise_splitting'=>__('If enabled, products falling under the same category will be grouped together and displayed in the picklist. Hence, making it easier while packing products.','wf-woocommerce-packing-list'),
	'wf_woocommerce_product_order_wise_splitting'=>__('Products from an order will be grouped together and displayed in the pick list, as per the order.','wf-woocommerce-packing-list'),
	'woocommerce_wf_packinglist_variation_data'=>__('Enable this option to display the variation information of the product beneath the product name in the picklist product table.','wf-woocommerce-packing-list'),
	'woocommerce_wf_packinglist_exclude_virtual_items'=>__('Enable this option to exclude the virtual deliverables like downloadable books from the picklist.','wf-woocommerce-packing-list'),
	'wf_picklist_product_meta_fields'=>__('Provisions displaying additional details pertaining to your product in the picklist. Click on Add/Edit existing order meta field button and enter appropriate field name/meta key to include respective custom product meta.','wf-woocommerce-packing-list'),
	'wt_picklist_product_attribute_fields'=>__('Allows displaying additional details pertaining to your product in the picklist. Click on Add/Edit product attribute button and enter appropriate field name/meta key to include respective custom product attribute.','wf-woocommerce-packing-list'),
);