<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>__('Classic', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template1.png',
	),
);