<?php
$arr=array(
	'wf_dispatchlabel_contactno_email'=>__('Allows displaying additional details pertaining to your order in the dispatch label. Defaulted to certain common meta values that can be selected from the drop-down. Click on Add/Edit order meta field button and into the pop up enter appropriate field name and meta key to include other custom meta.','wf-woocommerce-packing-list'),
	'wf_dispatchlabel_product_meta_fields'=>__('Product meta fields: Allows displaying additional details pertaining to your product in the dispatch label. Click on Add/Edit product meta field button and enter appropriate field name/meta key to include respective custom product meta.','wf-woocommerce-packing-list'),
	'wt_dispatchlabel_product_attribute_fields'=>__('Allows displaying additional details pertaining to your product in the dispatch label. Click on Add/Edit product attribute button and enter appropriate field name/meta key to include respective custom product attribute.','wf-woocommerce-packing-list'),
);

