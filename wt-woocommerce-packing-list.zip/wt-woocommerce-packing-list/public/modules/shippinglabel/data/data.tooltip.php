<?php
$arr=array(
	'woocommerce_wf_enable_multiple_shipping_label'=>__('Choose Yes to generate multiple labels on one page Enabling will prompt to input the number of labels in a row.','wf-woocommerce-packing-list'),
	'woocommerce_wf_packinglist_label_size'=>__('Choose the required size to be either full page or input a custom size by specifying the desired width and height in inches.','wf-woocommerce-packing-list'),
	'wf_shippinglabel_contactno_email'=>__('Allows displaying additional details pertaining to your order in the shipping label. Defaulted to certain common meta values that can be selected from the drop-down. Click on Add/Edit order meta field button and enter appropriate field name/meta key to include respective custom product meta','wf-woocommerce-packing-list'),
	'woocommerce_wf_attach_shippinglabel'=>__('Enabling this option will allow your customers to print the shipping label (via print button) from their order mail as well as after checkout.','wf-woocommerce-packing-list'),
);
