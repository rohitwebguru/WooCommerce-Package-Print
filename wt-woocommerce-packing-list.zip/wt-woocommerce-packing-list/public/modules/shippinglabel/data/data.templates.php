<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>__('Shipping Label 1', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template1.png',
	),
	array(
		'id'=>'template2',
		'title'=>__('Shipping Label 2', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template2.png',
	),
	array(
		'id'=>'template3',
		'title'=>__('Shipping Label 3', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template3.png',
	),
);