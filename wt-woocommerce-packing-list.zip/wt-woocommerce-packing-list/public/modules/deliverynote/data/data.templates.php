<?php
$template_arr=array(
	array(
		'id'=>'template1',
		'title'=>__('Classic', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template1.png',
	),
	array(
		'id'=>'template2',
		'title'=>__('Regal', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template2.png',
	),
	array(
		'id'=>'template3',
		'title'=>__('Imperial', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template3.png',
	),
);