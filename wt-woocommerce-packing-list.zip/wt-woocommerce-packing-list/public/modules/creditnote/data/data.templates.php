<?php
$template_arr=array(
	array(
		'id'=>'template3',
		'title'=>__('Credit Note 2', 'wf-woocommerce-packing-list'),
		'preview_img'=>'template3.png',
	)
);